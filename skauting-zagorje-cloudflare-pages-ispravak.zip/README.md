SKAUTING ZAGORJE – CLOUDFLARE PAGES

SADRŽAJ
- index.html        glavna stranica (u korijenu arhive)
- player-blue.png   fotografija igrača
- _headers          pravila zaglavlja i sprječavanje zastarjele HTML predmemorije
- _redirects        jednostavno preusmjeravanje nepoznatih putanja na početnu
- .nojekyll         podrška za GitHub Pages
- UPUTE.txt         upute za objavu

CLOUDFLARE PAGES – DIRECT UPLOAD
1. Otvorite Cloudflare Dashboard > Workers & Pages.
2. Odaberite postojeći Pages projekt.
3. Otvorite Deployments i pokrenite novi deployment (Create deployment).
4. Prenesite ovu ZIP arhivu ili raspakiranu mapu s datotekama.
5. Nakon uspješnog deploymenta otvorite adresu projekta koja završava s .pages.dev.
6. Napravite tvrdo osvježavanje preglednika: Ctrl+F5 (Windows) ili Cmd+Shift+R (Mac).

VAŽNO
- index.html mora biti u samom korijenu prenesenih datoteka, a ne unutar dodatne podmape.
- Ako .pages.dev prikazuje novu stranicu, a vlastita domena staru, provjerite DNS/projekt i očistite cache u Cloudflareu (Caching > Purge Cache).
- Ova arhiva zadržava postojeći sadržaj i dizajn izvornog ZIP-a; konfiguracija sprječava posluživanje stare HTML verzije iz cachea.
- Obrazac otvara korisnikovu e-mail aplikaciju; ne šalje podatke automatski.

GITHUB PAGES
1. Raspakirajte arhivu.
2. Prenesite sve datoteke u korijen GitHub repozitorija.
3. U Settings > Pages odaberite Deploy from a branch, granu main i / (root).
4. Spremite i pričekajte objavu.
