# Skauting Zagorje

Staticka web-stranica (HTML, CSS i JavaScript), spremna za Cloudflare Pages i GitHub Pages.

## Sadrzaj

- `index.html` — glavna stranica
- `player-blue.png` — slika igraca
- `.nojekyll` — osigurava da GitHub Pages ne pokusava obradivati datoteke kroz Jekyll
- `_headers` — sigurnosna HTTP zaglavlja za Cloudflare Pages (GitHub Pages ih ignorira)

## Cloudflare Pages — najjednostavnije postavljanje

1. Otvorite Cloudflare Dashboard: https://dash.cloudflare.com/
2. Idite na **Workers & Pages** → **Create** → **Pages**.
3. Odaberite **Upload assets** (Direct Upload).
4. Prenesite sadrzaj ove mape (datoteke i `.nojekyll`), ili ZIP raspakirajte pa odaberite mapu.
5. Kao naziv projekta odaberite npr. `skauting-zagorje`.
6. Pokrenite objavu. Cloudflare ce prikazati adresu stranice na `pages.dev`.

Za Git integraciju: stavite ove datoteke u GitHub repozitorij, zatim u Cloudflare Pages odaberite **Connect to Git**. Build command ostavite praznim, a **Build output directory** postavite na `/` odnosno korijensku mapu repozitorija (ovisno o sucelju).

## GitHub Pages

1. Napravite GitHub repozitorij, npr. `skauting-zagorje`.
2. Prenesite sve datoteke iz ove mape u korijen repozitorija, ukljucujuci `.nojekyll` i `_headers`.
3. Otvorite **Settings** → **Pages**.
4. Pod **Build and deployment** odaberite **Deploy from a branch**.
5. Odaberite granu `main` i mapu `/ (root)`, zatim **Save**.
6. Nakon objave stranica ce biti dostupna na adresi poput `https://KORISNICKO-IME.github.io/skauting-zagorje/`.

## Vazno

- Nije potreban Node.js, npm, framework ni build naredba.
- Zadrzite `index.html` i `player-blue.png` u istoj mapi.
- Obrazac ne salje podatke na web-posluzitelj. Priprema e-mail u korisnikovoj e-mail aplikaciji, a slanje korisnik potvrduje sam.
- Ako kasnije promijenite datoteke, ponovno ih prenesite ili napravite Git commit i push.
